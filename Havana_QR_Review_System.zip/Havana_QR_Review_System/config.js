/*
  SETUP:
  1. Create a project at https://supabase.com
  2. Open Project Settings -> API.
  3. Copy Project URL and anon/public key below.
  IMPORTANT: Never put a service_role key in a browser file.
*/
window.HAVANA_CONFIG = {
  SUPABASE_URL: "PASTE_YOUR_SUPABASE_PROJECT_URL_HERE",
  SUPABASE_ANON_KEY: "PASTE_YOUR_SUPABASE_ANON_KEY_HERE"
};